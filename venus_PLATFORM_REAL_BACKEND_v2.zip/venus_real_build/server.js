const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const HOST = '0.0.0.0';
const DATA_DIR = path.join(__dirname, 'data');
const STATE_FILE = path.join(DATA_DIR, 'state.json');

app.use(cors());
app.use(express.json({limit:'30mb'}));

function ensureFile(){
  fs.mkdirSync(DATA_DIR,{recursive:true});
  if(!fs.existsSync(STATE_FILE)) fs.writeFileSync(STATE_FILE,'{}','utf8');
}
function readFileState(){
  ensureFile();
  try{return JSON.parse(fs.readFileSync(STATE_FILE,'utf8')||'{}')}catch{return {}}
}
function writeFileState(s){
  ensureFile();
  fs.writeFileSync(STATE_FILE,JSON.stringify(s,null,2),'utf8');
}

let pgPool = null;
async function initDb(){
  if(!process.env.DATABASE_URL) return;
  try{
    const {Pool}=require('pg');
    pgPool=new Pool({connectionString:process.env.DATABASE_URL,ssl:{rejectUnauthorized:false}});
    await pgPool.query(`CREATE TABLE IF NOT EXISTS venus_state (key TEXT PRIMARY KEY, value JSONB NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
    console.log('Venus PostgreSQL database connected.');
  }catch(e){
    console.error('PostgreSQL unavailable; using local state.json:',e.message);
    pgPool=null;
  }
}

async function getState(key){
  if(pgPool){
    const r=await pgPool.query('SELECT value FROM venus_state WHERE key=$1',[key]);
    return r.rows[0]?.value ?? null;
  }
  return readFileState()[key] ?? null;
}
async function putState(key,value){
  if(pgPool){
    await pgPool.query(`INSERT INTO venus_state(key,value,updated_at) VALUES($1,$2,NOW()) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value, updated_at=NOW()`,[key,value]);
    return;
  }
  const s=readFileState(); s[key]=value; writeFileState(s);
}

app.get('/api/health',async(req,res)=>res.json({ok:true,service:'venus-study-platform',database:!!pgPool}));
app.get('/api/state/:key',async(req,res)=>{
  try{res.json({key:req.params.key,value:await getState(req.params.key)})}
  catch(e){res.status(500).json({error:e.message})}
});
app.put('/api/state/:key',async(req,res)=>{
  try{await putState(req.params.key,req.body?.value??null);res.json({ok:true,key:req.params.key})}
  catch(e){res.status(500).json({error:e.message})}
});
app.post('/api/state/:key',async(req,res)=>{
  try{await putState(req.params.key,req.body?.value??null);res.json({ok:true,key:req.params.key})}
  catch(e){res.status(500).json({error:e.message})}
});
app.get('/api/bootstrap',async(req,res)=>{
  try{
    if(pgPool){const r=await pgPool.query('SELECT key,value FROM venus_state'); const out={}; for(const row of r.rows) out[row.key]=row.value; return res.json(out)}
    return res.json(readFileState());
  }catch(e){res.status(500).json({error:e.message})}
});

const PUBLIC_DIR=path.join(__dirname,'public');
app.use(express.static(PUBLIC_DIR));
app.get('*',(req,res)=>res.sendFile(path.join(PUBLIC_DIR,'index.html')));

initDb().finally(()=>app.listen(PORT,HOST,()=>console.log(`Venus server running on http://${HOST}:${PORT}`)));
