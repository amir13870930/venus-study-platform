# Venus Study Platform 2.0

این نسخه Frontend فعلی ونوس را با یک Backend مشترک وصل می‌کند.

## اجرای محلی

```bash
npm install
npm start
```

سپس: http://localhost:3000

## دیتابیس واقعی

اگر متغیر محیطی `DATABASE_URL` تنظیم شود، سرور از PostgreSQL استفاده می‌کند و جدول `venus_state` را خودکار می‌سازد. اگر تنظیم نشده باشد، برای تست از `data/state.json` استفاده می‌شود.

برای استفاده واقعی بین گوشی و لپ‌تاپ، PostgreSQL را به سرویس متصل کنید و `DATABASE_URL` را در Environment Variables قرار دهید.

## Render

Build Command: `npm install`
Start Command: `npm start`
Root Directory: خالی

بعد از Deploy، آدرس عمومی Render را استفاده کنید.
