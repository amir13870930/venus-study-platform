
const express=require('express'); const cors=require('cors'); const fs=require('fs'); const path=require('path');
const app=express(); app.use(cors()); app.use(express.json({limit:'25mb'}));
const DATA=path.join(__dirname,'data','state.json');
function load(){try{return JSON.parse(fs.readFileSync(DATA,'utf8'))}catch(e){return {}}}
function save(x){fs.writeFileSync(DATA,JSON.stringify(x,null,2),'utf8')}
function merge(a,b){
 if(a==null)return b; if(b==null)return a;
 if(Array.isArray(a)&&Array.isArray(b)){
  if(a.every(x=>x&&typeof x==='object'&&('id' in x))||b.every(x=>x&&typeof x==='object'&&('id' in x))){const m=new Map(); [...a,...b].forEach(x=>{if(x&&x.id!=null)m.set(String(x.id),x)});return [...m.values()]}
  return b.length?a:b;
 }
 if(typeof a==='object'&&typeof b==='object'){const o={...a}; for(const k of Object.keys(b))o[k]=k in o?merge(o[k],b[k]):b[k]; return o}
 return b;
}
app.get('/api/health',(req,res)=>res.json({ok:true,service:'venus-shared-server'}));
app.get('/api/state/:key',(req,res)=>{const db=load(); const k=req.params.key; res.json({exists:Object.prototype.hasOwnProperty.call(db,k),value:db[k]??null})});
app.put('/api/state/:key',(req,res)=>{const db=load(); const k=req.params.key; db[k]=merge(db[k],req.body?.value); save(db); res.json({ok:true,value:db[k]})});
app.post('/api/state/:key',(req,res)=>{const db=load(); const k=req.params.key; db[k]=req.body?.value; save(db); res.json({ok:true,value:db[k]})});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(process.env.PORT||3000,()=>console.log('Venus shared server running'));
